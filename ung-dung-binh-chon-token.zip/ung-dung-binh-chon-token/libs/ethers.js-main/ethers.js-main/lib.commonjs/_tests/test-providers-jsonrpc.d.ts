export {};
//# sourceMappingURL=test-providers-jsonrpc.d.ts.map