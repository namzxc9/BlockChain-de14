export {};
//# sourceMappingURL=test-providers-ccip.d.ts.map