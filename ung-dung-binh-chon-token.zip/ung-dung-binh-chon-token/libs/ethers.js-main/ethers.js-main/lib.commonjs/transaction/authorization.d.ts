import type { Authorization, AuthorizationLike } from "./index.js";
export declare function authorizationify(auth: AuthorizationLike): Authorization;
//# sourceMappingURL=authorization.d.ts.map