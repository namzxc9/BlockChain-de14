/**
 *  A constant for the zero hash.
 *
 *  (**i.e.** ``"0x0000000000000000000000000000000000000000000000000000000000000000"``)
 */
export declare const ZeroHash: string;
//# sourceMappingURL=hashes.d.ts.map