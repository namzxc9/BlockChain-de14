/**
 *  A constant for the zero address.
 *
 *  (**i.e.** ``"0x0000000000000000000000000000000000000000"``)
 */
export declare const ZeroAddress: string;
//# sourceMappingURL=addresses.d.ts.map