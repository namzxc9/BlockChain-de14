import type { BytesLike } from "./data.js";
export declare function decodeBase64(textData: string): Uint8Array;
export declare function encodeBase64(_data: BytesLike): string;
//# sourceMappingURL=base64-browser.d.ts.map