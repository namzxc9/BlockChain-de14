/**
 *  @_ignore
 */
export declare function decodeBits(width: number, data: string): Array<number>;
//# sourceMappingURL=bit-reader.d.ts.map