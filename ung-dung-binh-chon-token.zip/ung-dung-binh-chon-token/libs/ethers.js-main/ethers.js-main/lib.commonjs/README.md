CommonJS Files
==============

The contents of this folder are for using `require` in CommonJS
projects.


Notes
-----

The contents are generated via the `npm run build-commonjs` target
using `tsc` and the `/tsconfig.commonjs.json` configuration.

Do not modify the files in this folder. They are deleted on `build-clean`.

To modify this `README.md`, see the `/output/post-build/lib.commonjs`.
