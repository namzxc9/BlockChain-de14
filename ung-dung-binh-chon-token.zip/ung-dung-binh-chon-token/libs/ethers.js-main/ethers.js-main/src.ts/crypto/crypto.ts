
export {
    createHash, createHmac, pbkdf2Sync, randomBytes
} from "crypto";
