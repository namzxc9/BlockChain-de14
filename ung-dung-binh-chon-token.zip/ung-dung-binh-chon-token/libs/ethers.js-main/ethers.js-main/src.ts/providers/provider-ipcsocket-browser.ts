const IpcSocketProvider = undefined;

export { IpcSocketProvider };
